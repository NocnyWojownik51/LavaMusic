const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'pomiń',
  description: 'Pomiń utwór.',
  inVc: true,
  sameVc: true,
  player: true,
  run: (client, interaction) => {
    const player = client.poru.players.get(interaction.guild.id);
    if (interaction.user.id !== player.currentTrack.info.requester.id)
      return interaction.reply({ content: `Nie możesz teraz użyć tego polecenia, ponieważ utwór jest odtwarzany przez innego użytkownika.`, ephemeral: true });
    player.stop();

    const embed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle(`\` ⏭ \` | Pomiń`)
      .setDescription('Pominięto bieżący utwór.');

    interaction.reply({ embeds: [embed] });
  },
};

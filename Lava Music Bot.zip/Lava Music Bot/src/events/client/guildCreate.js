const client = require('../../index');
const { EmbedBuilder, ChannelType } = require('discord.js');

module.exports = {
    name: "guildCreate"
};

client.once('guildCreate', async (guild) => {
    
    const welcomeChannel = client.channels.cache.find(channel => channel.type === ChannelType.GuildText)

    if (!welcomeChannel) return

    const welcomeEmbed = new EmbedBuilder()
    .setColor('Random')
    .setTitle(`\` 👋 \` | Thanks for adding`)
    .setDescription(`Thank you for adding the Lava Music  to your server, enjoy your music and if you have any problems, join our support server, where we will try to fix the problem with our bot. 💜`)
    .setFields(
        {
            name: 'Links:',
            value: `[Support server](https://discord.gg/cH6qDruEuV) | [Youtube channel](https://www.youtube.com/channel/UCDBDxm3Y4xpOfx8N51EWumQ) | [Add Bot](https://discord.com/api/oauth2/authorize?client_id=1174704906632970331&permissions=8&scope=bot)`
        }
    )
    try {
        welcomeChannel.send({embeds: [welcomeEmbed]})
    } catch (error) {
        console.log(error)
    }
})
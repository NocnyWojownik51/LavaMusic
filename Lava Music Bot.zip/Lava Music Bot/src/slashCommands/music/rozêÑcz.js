const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'rozłącz',
  description: 'Rozłącz bota z kanału głosowego.',
  userPermission: ["Administrator"],
  inVc: true,
  sameVc: true,
  player: true,
  run: async (client, interaction) => {
    const player = client.poru.players.get(interaction.guildId);

    player.destroy();
    const embed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle(`\` 📡 \` | Rozłącz`)
      .setDescription('Rozłączono bota z kanału głosowego.');

    return interaction.reply({
      embeds: [embed],
    });
  },
};

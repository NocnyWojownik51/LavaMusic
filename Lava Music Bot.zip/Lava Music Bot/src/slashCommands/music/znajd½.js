const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'znajdź',
  description: 'Znajdź utwór.',
  inVc: true,
  sameVc: true,
  player: true,
  current: true,
  options: [
    {
      name: 'pozycja',
      description: 'Pozycja utworu.',
      type: ApplicationCommandOptionType.Number,
      required: true,
      min_value: 0,
    },
  ],
  run: (client, interaction) => {
    const player = client.poru.players.get(interaction.guild.id);
    if (interaction.user.id !== player.currentTrack.info.requester.id)
      return interaction.reply({ content: `Nie możesz teraz użyć tego polecenia, ponieważ utwór jest odtwarzany przez innego użytkownika.`, ephemeral: true });

    const position = interaction.options.getNumber('pozycja', true);

    if (!player.currentTrack.info.isSeekable) {
      const embed = new EmbedBuilder()
        .setColor('Blue')
        .setTitle(`\` 🔍 \` | Znajdź`)
        .setDescription('Nie można wyszukać utworu.');

      interaction.reply({
        embeds: [embed],
      });
    } else {
      player.seekTo(position * 1000);

      const embed = new EmbedBuilder()
        .setColor('Blue')
        .setTitle(`\` 🔍 \` | Znajdź`)
        .setDescription(`Znalazłem utwór na pozycji ${position}.`);

      return interaction.reply({
        embeds: [embed],
      })
    }
  },
};
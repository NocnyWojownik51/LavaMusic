const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'przetasuj',
  description: 'Przetasuj kolejkę.',
  userPermission: ["Administrator"],
  inVc: true,
  sameVc: true,
  player: true,
  run: (client, interaction) => {
    const player = client.poru.players.get(interaction.guild.id);

    if (player.queue.length <= 2) {
      const embed = new EmbedBuilder()
        .setColor('Blue')
        .setTitle(`\` 🔀 \` | Przetasuj`)
        .setDescription("Nie można przetasować kolejki.");
      return interaction.reply({ embeds: [embed] });
    }

    player.queue.shuffle();

    const embed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle(`\` 🔀 \` | Przetasuj`)
      .setDescription('Przetasowano kolejkę.');

    return interaction.reply({
      embeds: [embed],
    });
  },
};

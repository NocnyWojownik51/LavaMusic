const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'wyczyść-kolejkę',
  description: 'Wyczyść kolejkę.',
  inVc: true,
  sameVc: true,
  player: true,
  run: (client, interaction) => {
    const player = client.poru.players.get(interaction.guild.id);
    if (interaction.user.id !== player.currentTrack.info.requester.id)
      return interaction.reply({ content: `Nie możesz teraz użyć tego polecenia, ponieważ utwór jest odtwarzany przez innego użytkownika.`, ephemeral: true });

    if (!player.queue.length) {
      const embed = new EmbedBuilder()
        .setColor('Red')
        .setTitle(`\` 🆑 \` | Wyczyść kolejkę`)
        .setDescription('Kolejka jest pusta.');

      return interaction.reply({
        embeds: [embed],
      });
    }

    const { length } = player.queue;
    player.queue.clear();

    const embed = new EmbedBuilder()
      .setColor('Red')
      .setTitle(`\` 🆑 \` | Wyczyść kolejkę`)
      .setDescription(`Wyczyszczono ${length} utworów z kolejki.`);

    return interaction.reply({
      embeds: [embed],
    });
  },
};

const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'wznów',
  description: 'Wznów odtwarzanie.',
  inVc: true,
  sameVc: true,
  player: true,
  run: (client, interaction) => {
    const player = client.poru.players.get(interaction.guild.id);
    if (interaction.user.id !== player.currentTrack.info.requester.id)
      return interaction.reply({ content: `Nie możesz teraz użyć tego polecenia, ponieważ utwór jest odtwarzany przez innego użytkownika.`, ephemeral: true });

    if (!player.isPaused) {
      const embed = new EmbedBuilder()
        .setColor('Blue')
        .setTitle(`\` ▶ \` | Wznawianie`)
        .setDescription('Odtwarzanie nie jest wstrzymane.');

      interaction.reply({
        embeds: [embed],
      });
    } else {
      const embed = new EmbedBuilder()
        .setColor('Blue')
        .setTitle(`\` ▶ \` | Wznawianie`)
        .setDescription('Odtwrzanie zostało wznowione.');

      player.pause(false);
      interaction.reply({
        embeds: [embed],
      });
    }
  },
};

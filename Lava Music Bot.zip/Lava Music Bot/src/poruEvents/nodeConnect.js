module.exports.run = (client, node) => {
  console.log(`[NODE] ${node.name} has been loaded successfully`.blue);
  console.log("----------------------------------------".white);
};
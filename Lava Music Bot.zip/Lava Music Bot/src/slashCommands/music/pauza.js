const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'pauza',
  description: 'Zatrzymaj odtwarzanie.',
  inVc: true,
  sameVc: true,
  player: true,
  run: async (client, interaction) => {
    const player = client.poru.players.get(interaction.guild.id);
    if (interaction.user.id !== player.currentTrack.info.requester.id)
      return interaction.reply({ content: `Nie możesz teraz użyć tego polecenia, ponieważ utwór jest odtwarzany przez innego użytkownika.`, ephemeral: true });

    if (player.isPaused) {
      const embed = new EmbedBuilder()
        .setColor('Blue')
        .setTitle(`\` ⏸ \` | Pauza`)
        .setDescription('Odtwarzanie jest obecnie zatrzymane.');

      return interaction.reply({
        embeds: [embed],
      });
    }

    player.pause(true);

    const embed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle(`\` ⏸ \` | Pause`)
      .setDescription('Odtwarzanie zostało zatrzymane.');

    return interaction.reply({
      embeds: [embed],
    });
  },
};

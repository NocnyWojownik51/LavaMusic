module.exports.run = (client, player) => {
    return player.destroy();
};
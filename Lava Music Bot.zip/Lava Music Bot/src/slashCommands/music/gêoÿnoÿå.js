const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'głośność',
  description: 'Ustawia głośność odtwarzania.',
  inVc: true,
  sameVc: true,
  player: true,
  options: [
    {
      name: 'głośność',
      description: 'Głośność, którą chcesz ustawić.',
      type: ApplicationCommandOptionType.Number,
      required: true,
      min_value: 0,
      max_value: 100,
    },
  ],
  run: (client, interaction) => {
    const player = client.poru.players.get(interaction.guild.id);
    if (interaction.user.id !== player.currentTrack.info.requester.id)
      return interaction.reply({ content: `Nie możesz teraz użyć tego polecenia, ponieważ utwór jest odtwarzany przez innego użytkownika.`, ephemeral: true });
    const volume = interaction.options.getNumber('głośność', true);
    player.setVolume(volume);

    const embed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle(`\` 🔊 \` | głośność`)
      .setDescription(`Głośność została ustawiona na **${volume}%**.`);

    interaction.reply({
      embeds: [embed],
    });
  },
};

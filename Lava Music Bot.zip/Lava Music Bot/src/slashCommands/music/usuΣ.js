const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'usuń',
  description: 'Usuń utwór.',
  userPermission: ["Administrator"],
  inVc: true,
  sameVc: true,
  player: true,
  options: [
    {
      name: 'utwór',
      description: 'Podaj utwór który chcesz usunąć.',
      type: ApplicationCommandOptionType.Number,
      required: true,
      min_value: 1,
    },
  ],
  run: (client, interaction) => {
    const player = client.poru.players.get(interaction.guild.id);
    const track = interaction.options.getNumber('utwór');

    if (track > player.queue.length) {
      const embed = new EmbedBuilder()
        .setColor('Blue')
        .setTitle(`\` 🧺 \` | Usuwanie`)
        .setDescription('Nie znaleziono utworu.');

      return interaction.reply({ embeds: [embed] });
    }

    player.queue.remove(track - 1);

    const embed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle(`\` 🧺 \` | Usuwanie`)
      .setDescription('Usunięto utwór z kolejki.');

    return interaction.reply({ embeds: [embed] });
  },
};

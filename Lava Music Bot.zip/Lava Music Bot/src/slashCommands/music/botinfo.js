const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'botinfo',
  description: 'Get info about the bot.',
  inVc: false,
  sameVc: false,
  player: false,
  run: async (client, interaction) => {

    const users = client.users.cache.filter(user => !user.bot)
    const usersSize = users.size

    await client.guilds.cache.fetch()
    const serverCount = client.guilds.cache.size

    const nodeJSversion = 'v18.16.0'
    const discordJSversion = 'v14.11.0'
    const discordBOTversion = 'v1.1.0'

    const days = Math.floor(client.uptime / 86400000)
    const hours = Math.floor(client.uptime / 3600000) % 24
    const minutes = Math.floor(client.uptime / 60000) % 60
    const seconds = Math.floor(client.uptime / 1000) % 60

    const commandsSize = client.slash.size

    const interactionDefer = await interaction.deferReply()

    const ping = interactionDefer.createdTimestamp - interaction.createdTimestamp

    const botInfoEmbed = new EmbedBuilder()
    .setColor('Random')
    .setTitle(`\` 🤖 \` | Bot Info`)
    .setFields(
        {
            name: '📊 Statistics:',
            value: `* **People:** ${usersSize}\n* **Servers:** ${serverCount}\n* **Commands:** ${commandsSize}\n*`
        },
        {
            name: `📋 Infomramtion:`,
            value: `* **Uptime:** ${days}d ${hours}h ${minutes}m ${seconds}s\n* **API delay:** ${ping}ms\n* **Websocket delay:** ${client.ws.ping}ms\n* **Node.js Version:** ${nodeJSversion}\n* **Discord.js Version:** ${discordJSversion}\n* **Discord Bot Version:** ${discordBOTversion}`
        },
        {
            name: '🌐 Links:',
            value: `[Invite](https://discord.com/api/oauth2/authorize?client_id=1115958972390846535&permissions=8&scope=bot) | [Support](https://discord.gg/sFhuw9xP7r) | [Developer](https://discord.gg/jgY3vstPrE)`
        }
    )
    
    interaction.editReply({embeds: [botInfoEmbed]})
  }
}
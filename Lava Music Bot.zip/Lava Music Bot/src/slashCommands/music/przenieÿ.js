const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'przenieś',
  description: 'Zamnień kolejność utworów w kolejce.',
  userPermission: ["Administrator"],
  inVc: true,
  sameVc: true,
  player: true,
  options: [
    {
      name: 'track',
      description: 'Podaj utwór który chcesz przenieść.',
      type: ApplicationCommandOptionType.Number,
      required: true,
      min_value: 1,
    },
    {
      name: 'position',
      description: 'Usuń utwór z kolejki.',
      type: ApplicationCommandOptionType.Number,
      required: true,
      min_value: 2,
    },
  ],
  run: (client, interaction) => {
    function moveArrayElement(arr, fromIndex, toIndex) {
      arr.splice(toIndex, 0, arr.splice(fromIndex, 1)[0]);
      return arr;
    }

    const player = client.poru.players.get(interaction.guild.id);
    if (interaction.user.id !== player.currentTrack.info.requester.id)
      return interaction.reply({ content: `Nie możesz teraz użyć tego polecenia, ponieważ utwór jest odtwarzany przez innego użytkownika.`, ephemeral: true });

    const from = interaction.options.getNumber('track');
    const to = interaction.options.getNumber('position');

    if (
      from === to ||
      isNaN(from) ||
      from < 1 ||
      from > player.queue.length ||
      isNaN(to) ||
      to < 1 ||
      to > player.queue.length
    )
      return interaction.reply("Ten utwór nie istnieje w kolejce.");

    const moved = player.queue[from - 1];
    moveArrayElement(player.queue, from - 1, to - 1);

    const embed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle(`\` 🔀 \` | Przenieś utwór`)
      .setDescription(`Przeniesiono utwór ${moved.info.title} na \`${to}\`.`);

    return interaction.reply({
      embeds: [embed],
    });
  },
};

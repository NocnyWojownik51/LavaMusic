const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Client } = require('discord.js');
const wait = require('node:timers/promises').setTimeout;
const ms = require('ms');

/**
 * @param {Client} client 
 */

module.exports.run = async (client, player, track) => {
  function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('loop')
        .setEmoji(`🔁`)
        .setStyle(ButtonStyle.Secondary),

      new ButtonBuilder()
        .setCustomId('volume-')
        .setEmoji(`🔉`)
        .setStyle(ButtonStyle.Danger),

      new ButtonBuilder()
        .setCustomId('p/p')
        .setEmoji(`▶`)
        .setStyle(ButtonStyle.Secondary),

      new ButtonBuilder()
        .setCustomId('volume+')
        .setEmoji(`🔊`)
        .setStyle(ButtonStyle.Success),

      new ButtonBuilder()
        .setCustomId('skip')
        .setEmoji(`⏭`)
        .setStyle(ButtonStyle.Secondary),
    );

  const embed = new EmbedBuilder()
    .setAuthor({
      name: `Now Playing`,
      iconURL: track.info.requester.displayAvatarURL(),
    })
    .setColor('Blue')
    .setDescription(`**Track**: [${track.info.title}](${track.info.uri})\n**Author**: ${track.info.author}\n**Source**: ${capitalizeFirstLetter(`${track.info.sourceName}`)}\n**Duration**: ${ms(track.info.length)}`,
    )
    .setImage(track.info.image);

  const channel = client.channels.cache.get(player.textChannel)
  await channel?.send({ embeds: [embed], components: [row] })

  
  
  

  try {

    setInterval(async() => {
      await wait(2300)
      const messages = await channel.messages.fetch({ limit: 1 })
      await wait(1000)
      const message = await messages.first()
      await wait(1000)
      await message.delete(message)
      await wait(1000)
    }, 1000*60*4)

  } catch (error) {
    console.log(error)
  }
};